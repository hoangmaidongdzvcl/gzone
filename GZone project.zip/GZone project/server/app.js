require('dotenv').config({ path: './config.env' });
const express = require('express');
const axios = require('axios');
const path = require('path');
const app = express();
const port = 80;

//cung cap file tu thu muc public
app.use(express.static(path.join(__dirname, '../public')));

//ma hoa url thanh base64
function base64EncodeUrl(url) {
  return Buffer.from(url).toString('base64').replace(/=/g, '');
}

//route kiem tra url tu virus total
app.get('/check-url', async (req, res) => {
  const url = req.query.url;
  if (!url) {
    return res.status(400).send('Vui lòng cung cấp một URL để kiểm tra.');
  }

  const apiKey = process.env.VIRUS_TOTAL_API_KEY;
  if (!apiKey) {
    return res.status(500).send('API key bị thiếu.');
  }

  const encodedUrl = base64EncodeUrl(url);
  const endpoint = `https://www.virustotal.com/api/v3/urls/${encodedUrl}`;

  try {
    const response = await axios.get(endpoint, {
      headers: {
        'x-apikey': apiKey
      }
    });

      //lay du lieu tu api
    const data = response.data.data;
    const attributes = data.attributes;

    //kiem tra web co an toan hay k
    const maliciousCount = attributes.last_analysis_stats.malicious;

    //tra ket qua ve website
    if (maliciousCount < 3) {
      return res.send('Website an toàn'); 
    } else {
      return res.send('Website không an toàn'); 
    }

  } catch (error) {
    console.error('Error:', error);
    return res.status(500).send('Đã xảy ra lỗi. Vui lòng thử lại sau.');
  }
});

//chuyen huong den duong dan 404 khi ng dung yeu cau 1 duong dan k xac dinh
app.use((req, res) => {
  const filePath = path.join(__dirname, '../public', '404.html');
  res.status(404).sendFile(filePath);
});

// Start the server
app.listen(port, () => {
  console.log(`GZone Server Start!`);
});
