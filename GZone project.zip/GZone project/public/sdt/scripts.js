const API_KEY = 'e6092e80f116b091ff0f4790fc109a64';  // Thay thế bằng API Key của bạn

function checkPhoneNumber() {
    const phoneNumber = document.getElementById('phoneNumber').value;
    if (phoneNumber === '') {
        alert('Vui lòng nhập số điện thoại.');
        return;
    }

    const url = `https://apilayer.net/api/validate?access_key=${API_KEY}&number=${phoneNumber}&country_code=VN&format=1`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            let resultText = '';
            let resultClass = '';
            
            if (data.valid) {
                resultText = `Số điện thoại ${phoneNumber} An Toàn.`;
                resultClass = 'safe';
            } else {
                resultText = `Số điện thoại ${phoneNumber} có thể là số lừa đảo.`;
                resultClass = 'unsafe';
            }
            
            document.getElementById('result').textContent = resultText;
            document.getElementById('result').className = `result ${resultClass}`;
        })
        .catch(error => {
            console.error('Có lỗi xảy ra:', error);
            alert('Không thể kiểm tra số điện thoại. Vui lòng thử lại.');
        });
}

// Toggle menu for mobile
function toggleMenu() {
    const menuContainer = document.querySelector('.menu-container');
    menuContainer.classList.toggle('open');
}
